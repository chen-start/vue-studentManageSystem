## 目的
与学生管理系统搭配而创建的接口

## 技术栈
nodejs + express + mongodb

### 接口个数
/getStudent/:page?/:pageSize? 获取学生接口

/getOneStudent/:id 根据id获取学生信息接口

/postStudent 提交添加学生信息接口

/putStudent 修改学生接口

/deleteStudent 删除单个学生接口

/deleteMoreStudent 批量删除接口