<template>
    <div class="power">
        <h1>权限管理页面</h1>
    </div>
</template>