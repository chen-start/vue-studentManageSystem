<template>
    <div class="user">
        <h1>用户管理页面</h1>
    </div>
</template>