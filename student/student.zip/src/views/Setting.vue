<template>
    <div class="setting">
        <h1>设置页面</h1> 
    </div>
</template>